import numpy as np

def add_galactic_prior(self,site_data,galactic_l,VI_VK_data_file='besgiant.dat'):

	""" Set up the initial conditions to use a galactic model prior on theta_star, rho, t_E.

		site_data is a dictionary, indexed by site name, with each entry being a tuple of
			(VmI_source, I_RC, VmI_RC)

	"""

	self.use_galactic_prior = True

	self.galactic_prior_data = site_data

	# constants
	VmI_RC_0 = 1.06

	# Interpolate I_RC_0 from Table 1 of Nataf et al, 2013, ApJ, 769, 88
	from scipy.interpolate import PchipInterpolator
	longitude = np.arange(21) - 9
	I0 = np.array([14.662,14.624,14.620,14.619,14.616,14.605,14.589,14.554,14.503,14.443, \
				14.396,14.373,14.350,14.329,14.303,14.277,14.245,14.210,14.177,14.147,14.121])
	interp = PchipInterpolator(longitude,I0)

	if galactic_l > 300:
		galactic_l -= 360.0

	if galactic_l < -9.0 or galactic_l > 11.0:
		raise ValueError('galactic_l must be between -9 and +11')

	self.I_RC_0 = interp(galactic_l)

	# Average over sites

	# Calculate VmI_source_0 = VmI_source + VmI_RC_0 - VmI_RC
	VmI_source_0 = [site_data[site][0] + VmI_RC_0 - site_data[site][2] for site in site_data]

	self.VmI_source_0 = np.mean(VmI_source_0)

	self.VmK_source_0 = self.VItoVK(self.VmI_source_0,VI_VK_data_file)


def galactic_ln_prior_prob(self,p,fs):

	I_source_0 = np.mean([self.zp - 2.5*np.log10(fs[site]) + self.I_RC_0 - self.galactic_prior_data[site][1] \
							for site in self.galactic_prior_data])

	V_source_0 = self.VmI_source_0 + I_source_0

	qlog2thetastar  = 0.5410+0.2667*self.VmK_source_0 - V_source_0/5.0
	theta_star = 10.**qlog2thetastar/2.0
	
	# add some stuff to get the galaxy ln prior

	return 0.0


